//
//  MIT license
//  Copyright (C) 2024 Intel Corporation
//  SPDX-License-Identifier: MIT
//


#include "ggml-sycl.h"

int main() {
    ggml_backend_sycl_print_sycl_devices();
    return 0;
}
