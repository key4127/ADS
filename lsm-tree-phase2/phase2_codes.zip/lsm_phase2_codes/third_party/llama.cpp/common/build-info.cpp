int LLAMA_BUILD_NUMBER = 4953;
char const *LLAMA_COMMIT = "e07d8fea";
char const *LLAMA_COMPILER = "cc (Ubuntu 13.3.0-6ubuntu2~24.04) 13.3.0";
char const *LLAMA_BUILD_TARGET = "x86_64-linux-gnu";
